# calibre wide preferences

### Begin group: DEFAULT
 
# database path
# Pfad zur Datenbank, in der die Bücher gespeichtert sind
database_path = 'C:\\Users\\Raimond/library1.db'
 
# filename pattern
# Verhaltensmuster zum Ermitteln der Metadaten aus den Dateinamen
filename_pattern = u'(?P<title>.+) - (?P<author>[^_]+)'
 
# isbndb com key
# Zugangsschlüssel für isbndb.com
isbndb_com_key = ''
 
# network timeout
# Standardeinstellung der Zeitüberschreitung bei Netzwerkverbindungen (in Sekunden)
network_timeout = 5
 
# library path
# Pfad zum Verzeichnis, in dem die Buchbibliothek gespeichert ist
library_path = u'C:\\Program Files (x86)\\Calibre Portable\\Calibre Library'
 
# language
# Sprache, in der die Benutzeroberfläche dargestellt wird
language = 'de'
 
# output format
# Standardzielformat für eBook-Konvertierungen.
output_format = 'epub'
 
# input format order
# Geordnete Liste der Formate, die bei der Eingabe bevorzugt werden.
input_format_order = cPickle.loads('\x80\x02]q\x01(U\x04EPUBq\x02U\x04AZW3q\x03U\x04MOBIq\x04U\x03LITq\x05U\x03PRCq\x06U\x03FB2q\x07U\x04HTMLq\x08U\x03HTMq\tU\x04XHTMq\nU\x05SHTMLq\x0bU\x05XHTMLq\x0cU\x03ZIPq\rU\x04DOCXq\x0eU\x03ODTq\x0fU\x03RTFq\x10U\x03PDFq\x11U\x03TXTq\x12e.')
 
# read file metadata
# Metadaten aus Dateien lesen
read_file_metadata = True
 
# worker process priority
# Die Priorität des Arbeitsprozesses. Eine höhere Priorität bedeutet ein schnelleres Arbeiten, verbraucht aber mehr Ressourcen. Die meisten Aufgaben wie Konvertierungen/News herunteraden/Bücher hinzufügen/etc. werden von dieser Einstellung beeinflusst.
worker_process_priority = 'normal'
 
# swap author names
# Vor- und Nachname des Autors vertauschen beim Einlesen von Metadaten
swap_author_names = False
 
# add formats to existing
# Neue Formate zu schon vorhandenen Bucheinträgen hinzufügen
add_formats_to_existing = False
 
# check for dupes on ctl
# Beim Kopieren in eine andere Bibliothek auf Duplikate prüfen
check_for_dupes_on_ctl = False
 
# installation uuid
# Installation UUID
installation_uuid = '52cba687-084a-46e8-9b83-f68e924e6e60'
 
# new book tags
# Schlagwörter, die neu hinzugefügten Büchern angehängt werden sollen
new_book_tags = cPickle.loads('\x80\x02]q\x01.')
 
# mark new books
# Neu hinzugefügte Bücher markieren. Diese Markierung ist temporär und wird nach dem Neustart von Calibre automatisch entfernt.
mark_new_books = False
 
# saved searches
# Liste der benannten gespeicherten Suchen
saved_searches = cPickle.loads('\x80\x02}q\x01.')
 
# user categories
# Vom Benutzer erstellte Schlagwortbrowser-Kategorien
user_categories = cPickle.loads('\x80\x02}q\x01.')
 
# manage device metadata
# Wie und wann Calibre Metadaten auf dem Gerät aktualisiert.
manage_device_metadata = 'manual'
 
# limit search columns
# Wenn Sie ohne Suchpräferenzen suchen, wie zum Beispiel "rot" statt "title:rot", werden die durchsuchten Spalten auf die unten angezeigten eingegrenzt.
limit_search_columns = False
 
# limit search columns to
# Spalten auswählen, die beim Weglassen von Präfixen durchsucht werden sollen, z. B. bei der Suche nach "rot" anstatt nach "title:rot". Geben Sie eine kommagetrennte Liste von Suchnamen ein. Nur wirksam, wenn Sie oben die Option zur Begrenzung von Suchspalten aktivieren.
limit_search_columns_to = cPickle.loads('\x80\x02]q\x01(U\x05titleq\x02U\x07authorsq\x03U\x04tagsq\x04U\x06seriesq\x05U\tpublisherq\x06e.')
 
# use primary find in search
# Im Suchfeld eingegebene Zeichen entsprechen auch ihren akzentuierten Formen, basierend auf der in der Benutzeroberfläche eingestellten Sprache. Bei englischer Spracheinstellung findet beispielsweise eine Suche nach "n" sowohl "ñ" als auch "n", bei spanischer Spracheinstellung wird aber nur "n" gefunden. Beachten Sie, dass dies bei sehr großen Bibliotheken deutlich langsamer als eine normale Suche ist. Weiterhin wird diese Option keine Auswirkung haben, falls Sie die Groß-/Kleinschreibung berücksichtigende Suche anschalten.
use_primary_find_in_search = True
 
# case sensitive
# Berücksichtigung von Groß-/Kleinschreibung bei Suchvorgängen
case_sensitive = False
 
# migrated
# For Internal use. Don't modify.
migrated = False
 


